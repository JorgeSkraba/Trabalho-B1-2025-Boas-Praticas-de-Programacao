package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class Cliente extends Pessoa{
    private boolean maioridade;
    private String pet;
    private boolean cuidadoso;

    public Cliente(int idade, String nome, int cpf, boolean maioridade, String pet, boolean cuidadoso, int carteira){
        super(idade, nome, cpf, carteira);
        this.maioridade = maioridade;
        this.pet = pet;
        this.cuidadoso = cuidadoso;
    }

           //recebe animal
    public void cuidar(Animal animal){
          if(this.cuidadoso && animal.getEstadoSaude() == "ruim"){
              System.out.print("O animal passou de "+animal.getEstadoSaude()+" para ");
              animal.setEstadoSaude("Medio");
              System.out.println(animal.getEstadoSaude());
              return;
          }

        if(this.cuidadoso && animal.getEstadoSaude() == "pessimo"){
            System.out.print("O animal passou de "+animal.getEstadoSaude()+" para ");
            animal.setEstadoSaude("ruim");
            System.out.println(animal.getEstadoSaude());
            return;
        }

        System.out.println("O dono não é cuidadoso!");
    }

    public boolean isMaioridade() {
        return maioridade;
    }

    public void setMaioridade(boolean maioridade) {
        this.maioridade = maioridade;
    }

    public String getPet() {
        return pet;
    }

    public void setPet(String pet) {
        this.pet = pet;
    }

    public boolean isCuidadoso() {
        return cuidadoso;
    }

    public void setCuidadoso(boolean cuidadoso) {
        this.cuidadoso = cuidadoso;
    }

}
