package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

import java.util.Scanner;

public class Exames {
    private int valor;
    private boolean resultado = false;
    private String descricao_exame;

    public Exames(boolean resultado, int valor) {
        this.resultado = resultado;
        this.valor = valor;

    }

    public void resultados() {
        if (valor == 1) {
            resultado = true;

        }
        if (valor == 2) {
            System.out.println("O exame do animal foi negativo");
        }
    }

    public void texto() {
        if (resultado == true) {
            System.out.println(descricao_exame);
        }
    }

    public boolean isResultado() {
        return resultado;
    }

    public void setResultado(boolean resultado) {
        this.resultado = resultado;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public String getDescricao_exame() {
        return descricao_exame;
    }

    public void setDescricao_exame(String descricao_exame) {
        this.descricao_exame = descricao_exame;
    }
}


