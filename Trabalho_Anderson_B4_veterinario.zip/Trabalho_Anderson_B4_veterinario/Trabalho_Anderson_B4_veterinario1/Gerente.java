package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;


import java.util.ArrayList;
import java.util.List;

public class Gerente extends Funcionario {

    private List<Secretario> ListaSecretario = new ArrayList<>();
    private List<Veterinario> ListaVeterinario = new ArrayList<>();


    public Gerente (int idade, String nome, int cpf, int salario, String funcao, String cargaHoraria, int carteira){
        super(idade, nome, cpf, salario, funcao, cargaHoraria, carteira);
    }

    public List<Secretario> getListaSecretario() {
        return ListaSecretario;
    }

    public void setListaSecretario(List<Secretario> listaSecretario) {
        ListaSecretario = listaSecretario;
    }

    public List<Veterinario> getListaVeterinario() {
        return ListaVeterinario;
    }

    public void setListaVeterinario(List<Veterinario> listaVeterinario) {
        ListaVeterinario = listaVeterinario;
    }

    public void contratar (Secretario SecretarioNovo, Veterinario VeterinarioNovo){
      if(SecretarioNovo != null){
          ListaSecretario.add(SecretarioNovo);
          System.out.println("O(a) secretário(a) "+SecretarioNovo.getNome()+" foi contradado(a)!");
      }

        if(VeterinarioNovo != null){
            ListaVeterinario.add(VeterinarioNovo);
            System.out.println("O(a) veterinário(a) "+VeterinarioNovo.getNome()+" foi contradado(a)!");
        }
    }
    
    public void demitir(Secretario Secretario, Veterinario Veterinario){
        if(Secretario != null){
            ListaSecretario.remove(Secretario);
            System.out.println("O(a) secretário(a) "+Secretario.getNome()+" foi demitido(a)!");
        }

        if(Veterinario != null){
            ListaVeterinario.remove(Veterinario);
            System.out.println("O(a) veterinário(a) "+Veterinario.getNome()+" foi demitido(a)!");
        }
    }



}
