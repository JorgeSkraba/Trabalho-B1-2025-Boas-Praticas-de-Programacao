package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class Veterinario extends Funcionario{

    public Veterinario (int idade, String nome, int cpf, int salario, String funcao, String cargaHoraria, int carteira){
        super(idade, nome, cpf, salario, funcao, cargaHoraria, carteira);
    }

    public void vacinar(Cachorro cachorro, Gato gato){
        if(gato != null && gato.getCarteiraVacina() == "naoVacinado"){
            gato.setCarteiraVacina("Vacinado");
            System.out.println("O gato foi vacinado!");
        }else if(gato != null){
            System.out.println("O gato já está vacinado!");
        }

        if(cachorro != null && cachorro.getCarteiraVacina() == "naoVacinado"){
            cachorro.setCarteiraVacina("Vacinado");
            System.out.println("O cachorro foi vacinado!");
        }else if(cachorro != null){
            System.out.println("O cachorro já está vacinado!");
        }
    }

    public void medicar(Animal animal){
        if(animal.getEstadoSaude() == "ruim" || animal.getEstadoSaude() == "pessimo"){
            animal.setEstadoSaude("bom");
            System.out.println("O animal foi medicado!");
        }else{
            System.out.println("O animal nao precisa ser medicado");
        }
    }

    public void fazerExame(){
        //recebe objeto exame e pode trazer alguma informação ou identificação
    }

    public void darSoro(Animal animal){
        if(animal.getEstadoSaude() == "ruim" || animal.getEstadoSaude() == "pessimo"){
            animal.setEstadoSaude("bom");
            System.out.println("O animal foi tratado com Soro!");
        }else{
            System.out.println("O animal nao precisa ser medicado");
        }
    }

    public void atender(Cliente cliente){
        System.out.println("O(a) cliente "+cliente.getNome()+" foi atendido(a)");
    }

    // Método para cobrar exame
    public void cobrarExame(Veterinario veterinario, Animal animal) {
        if(animal.getEstadoSaude() == "ruim" || animal.getEstadoSaude() == "pessimo"){
            System.out.println(veterinario.getNome() + " cobrou por um exame veterinário.");
        }else{
            System.out.println("O animal não precisa de exame!");
        }
    }
}
