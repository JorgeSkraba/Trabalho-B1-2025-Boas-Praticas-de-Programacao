package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {



        Scanner scanner = new Scanner(System.in);

        // lista de animal geral utilizada para fazer o cadastro dos animais e consulta do mesmo.
        List<Animal> listaAnimalGeral = new ArrayList<>();

        // menu do sistema do veterianario
        int opcao = 0;
        do {
            System.out.println("Olá, escolha uma das opções abaixo: \n");
            System.out.println("1.Realizar Consulta\n" +
                    "2.Cadastrar Animal \n" +
                    "3.Agendar Consulta \n" +
                    "4.Agendar Exame \n" +
                    "5.Buscar Animal\n" +
                    "6.Sair\n");
            ;
            opcao = scanner.nextInt();
            switch (opcao){
                case 1:

                    System.out.println("Sistema de Consulta \n");

                    System.out.print("Informe o nome do animal: ");
                    String nome = scanner.next();
                    System.out.print("Informe o peso do animal: ");
                    int peso = scanner.nextInt();

                    System.out.print("Informe a temperatura corporal do animal: ");
                    int temperatura = scanner.nextInt();

                    System.out.print("Informe a taxa de respiração do animal respirações por minuto: ");
                    int respiracao = scanner.nextInt();

                    System.out.print("Informe a frequência cardíaca do animal batimentos por minuto: ");
                    int batimentos = scanner.nextInt();

                    System.out.println("\nDiagnóstico Clínico: \n");
                    Consulta consulta = new Consulta(peso, temperatura, respiracao, batimentos);
                    Exames exames = new Exames(false, 0);
                    consulta.gerardianostico();

                    if (consulta.isNecessitaExame() == true) {
                        System.out.println("\nO Exame do animal foi positivo ou negatino (digite 1 para positivo ou 2 para negativo): ");
                        int valor = scanner.nextInt();
                        scanner.nextLine();
                        exames.setValor(valor);
                    }
                    exames.resultados();

                    if(exames.isResultado() == true) {
                        System.out.print("Descreva o resultado no Exame: ");
                        String texto = scanner.nextLine();
                        exames.setDescricao_exame(texto);
                    }

                    exames.getDescricao_exame();
                    System.out.println();

                    System.out.println("Resumo da consulta: \n");
                    System.out.println("O peso do seu animal é " + consulta.getPeso());
                    System.out.println("O temperatura do seu animal é " + consulta.getTemperatura());
                    System.out.println("A respiraçao do seu animal por minutos é " + consulta.getRespiraçao());
                    System.out.println("O batimentos do seu animal por minutos é " + consulta.getBatimentos());


                    if(exames.isResultado() == true){
                        System.out.println("Descrição do exame: " + exames.getDescricao_exame() + "\n");
                    }


                    break;
                case 2:
                    System.out.println("Cadastrar Animal");

                    System.out.println("Nome do animal");
                    String nomeAnimal = scanner.next();

                    System.out.println("idade do animal");
                    int idadeAnimal = scanner.nextInt();

                    System.out.println("Tipo do animal");
                    String tipo = scanner.next();

                    System.out.println("Raça do animal");
                    String raca = scanner.next();

                    System.out.println("Estado de saude do animal");
                    String estadoSaude = scanner.next();

                    System.out.println("Digite o nome do Dono do Animal");
                    String nomeDonoAnimal = scanner.next();

                    System.out.println("Cadastro realizado com sucesso");


//                for (int i = 0; i < listaAnimalGeral.size(); i++) {
//
//                }

                    Animal animal1 = new Animal(nomeAnimal,tipo, raca,
                            idadeAnimal, estadoSaude, nomeDonoAnimal);

                    listaAnimalGeral.add(animal1);

                    break;
                case 3:
                    Secretario novoSecretario = new Secretario(18,"joselito",123456, 1500, "atendente", "44 horas semanal", 1234562);
                    Cliente clienteNovo = new Cliente(18,"jose scraba", 12345678, true,"magrelin", true, 123456 );

                    System.out.println("Agendar consulta");
                    System.out.println("Informe a data da consulta: ");
                    String data = scanner.next();
                    System.out.println("Informe o convênio: ");
                    String convenio = scanner.next();
                    System.out.println("Informe a duração da consulta: ");
                    double duracao = scanner.nextInt();
                    System.out.println("Informe o valor da consulta: ");
                    double valor = 120 * (duracao /60);
                    novoSecretario.agendar(clienteNovo,data);
                    System.out.println("valor da consulta " + valor);

                    break;
                case 4:
                    System.out.println("Agendar exame");
                    System.out.println("Informe a data para realizar o exame: ");
                    String dataExame = scanner.next();
                    System.out.println("Informe o tipo de exame: ");
                    String tipoExame = scanner.next();
                    System.out.println("Informe o valor deste exame: ");
                    int valorExame = scanner.nextInt();
                    break;

                case 5:
                    System.out.println("Buscar animal na lista: ");
                    System.out.println("Digite o nome do Animal: ");
                    String consultarAnimal = scanner.next();
                    System.out.println("Digite o nome do dono: ");
                    String nomeDono = scanner.next();

                    Animal animalConsulta = new Animal();
                    animalConsulta.procurarAnimal(nomeDono, consultarAnimal, listaAnimalGeral);
                    break;
                case 6:
                    System.out.println("Saindo do sistema");
                    break;
            }

        }while(opcao != 6);
        
    }
}
