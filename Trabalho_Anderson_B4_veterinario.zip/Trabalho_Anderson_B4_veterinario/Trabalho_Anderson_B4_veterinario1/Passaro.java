package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class Passaro extends Animal {
    private String corPena;

    public Passaro(String nome, String tipo, String raca, int idade, String estadoSaude, String nomeDono, String corPelugem,String carteiraVacina){
        super(nome, tipo,raca,idade,estadoSaude,nomeDono);
        this.corPena = corPena;

    }

    public Passaro(){

    }

    public void voar(){

    }
    public void bicar(){

    }
    public void fazerNinho(){

    }
    public void botarOvo(){

    }

}
