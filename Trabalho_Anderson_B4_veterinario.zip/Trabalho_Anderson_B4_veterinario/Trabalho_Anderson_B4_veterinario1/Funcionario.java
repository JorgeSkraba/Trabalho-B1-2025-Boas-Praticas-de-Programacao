package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class Funcionario extends Pessoa{
    private int salario;
    private String funcao;
    private String cargaHoraria;

    public Funcionario(int idade, String nome, int cpf, int salario, String funcao, String cargaHoraria, int carteira){
        super(idade, nome, cpf, carteira);
        this.salario = salario;
        this.funcao = funcao;
        this.cargaHoraria = cargaHoraria;
    }

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public String getCaragHoraria() {
        return cargaHoraria;
    }

    public void setCaragHoraria(String cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }
}
