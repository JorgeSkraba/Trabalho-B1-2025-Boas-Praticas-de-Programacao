package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

// Classe PetShop
public class Instituicao {
    // Atributos
    private int renda;
    private String nome;
    private double cnpj;
    private String endereco;

    // Construtor da classe PetShop
    public Instituicao(int renda, String nome, double cnpj, String endereco) {
        this.renda = renda;
        this.nome = nome;
        this.cnpj = cnpj;
        this.endereco = endereco;
    }

    // Getters e Setters
    public int getRenda() {
        return renda;
    }

    public void setRenda(int renda) {
        this.renda = renda;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getCnpj() {
        return cnpj;
    }

    public void setCnpj(int cnpj) {
        this.cnpj = cnpj;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    // Método para vender medicação
    public void venderMedicao(Cliente cliente, int valorMedicacao) {
        if(cliente.getCarteira() > valorMedicacao){
            cliente.setCarteira(cliente.getCarteira() - valorMedicacao);
            this.renda += valorMedicacao;
            System.out.println("O(a) cliente "+cliente.getNome()+" comprou "+valorMedicacao+" reais em remédios");
            return;
        }else{
            System.out.println("O cliente não possui dinheiro o suficiente!");
        }
    }

    // Método para pagar funcionário
    public void pagarFuncionario(Secretario secretario, Veterinario veterinario, Gerente gerente, int valorSalario1, int valorSalario2, int valorSalario3) {
        if(secretario != null && valorSalario1 < this.renda){
            secretario.setCarteira(secretario.getCarteira() + valorSalario1);
            this.renda -= valorSalario1;
            System.out.println("O(a) secretario(a) "+secretario.getNome()+" recebeu "+valorSalario1+" reais");
        }
        if(valorSalario1> this.renda){
            System.out.println("A instituicao nao possui o dinheiro suficiente!");
        }

        if(veterinario != null && valorSalario2 < this.renda){
            veterinario.setCarteira(veterinario.getCarteira() + valorSalario2);
            this.renda -= valorSalario2;
            System.out.println("O(a) veterinário(a) "+veterinario.getNome()+" recebeu "+valorSalario2+" reais");
        }
        if(valorSalario2> this.renda){
            System.out.println("A instituicao nao possui o dinheiro suficiente!");
        }

        if(gerente != null && valorSalario3 < this.renda){
            gerente.setCarteira(gerente.getCarteira() + valorSalario3);
            this.renda -= valorSalario3;
            System.out.println("O(a) gerente "+gerente.getNome()+" recebeu "+valorSalario3+" reais");
        }
        if(valorSalario3> this.renda){
            System.out.println("A instituicao nao possui o dinheiro suficiente!");
        }
    }

    // Método para comprar itens
    public void comprarItens(int valorItens) {
        if(this.renda > valorItens){
            this.renda -= valorItens;
            System.out.println("O valor "+valorItens+" foi comprado em remédios");
            return;
        }else{
            System.out.println("A instituicao nao possui dinheiro para essa compra!");
        }

    }
}