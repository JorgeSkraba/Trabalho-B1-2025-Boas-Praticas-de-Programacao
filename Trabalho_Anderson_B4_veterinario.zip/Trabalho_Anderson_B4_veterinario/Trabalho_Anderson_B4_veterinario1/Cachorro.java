package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class Cachorro extends Animal {
    private String corPelugem;
    private String carteiraVacina;

    public Cachorro(String nome, String tipo, String raca, int idade, String estadoSaude, String nomeDono, String corPelugem,String carteiraVacina){
        super(nome, tipo,raca,idade,estadoSaude,nomeDono);
        this.corPelugem = corPelugem;
        this.carteiraVacina = carteiraVacina;

    }

    public Cachorro(){

    }

    public void cavar(){

    }
    public void latir(){

    }
    public void vomitar(){

    }
    public void morder(){

    }

    public String getCorPelugem() {
        return corPelugem;
    }

    public void setCorPelugem(String corPelugem) {
        this.corPelugem = corPelugem;
    }

    public String getCarteiraVacina() {
        return carteiraVacina;
    }

    public void setCarteiraVacina(String carteiraVacina) {
        this.carteiraVacina = carteiraVacina;
    }
}
