package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class Secretario extends Funcionario{

    public Secretario (int idade, String nome, int cpf, int salario, String funcao, String cargaHoraria, int carteira){
        super(idade, nome, cpf, salario, funcao, cargaHoraria, carteira);
    }

    public void agendar(Cliente cliente, String data){
        System.out.println("A consulta com "+cliente.getNome()+" foi agendada para "+data);
    }

    public void atender(Cliente cliente){
        System.out.println("O(a) cliente "+cliente.getNome()+" foi atendido");
    }
}
