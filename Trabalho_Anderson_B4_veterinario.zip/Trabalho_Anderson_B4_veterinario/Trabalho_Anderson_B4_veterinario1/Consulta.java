package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class Consulta {
    private double peso;
    private double temperatura;
    private int respiraçao;
    private int batimentos;
    private boolean necessitaExame = false;
    private String nome;
    public Consulta(double peso, double temperatura, int respiraçao, int batimentos){
        this.peso = peso;
        this.temperatura = temperatura;
        this.respiraçao = respiraçao;
        this.batimentos = batimentos;
    }

    public boolean gerardianostico(){

        if(peso < 30.0){
            System.out.println("Peso abaixo do ideal");
            necessitaExame = true;
        }
        if (temperatura > 37){
            System.out.println("Temperatura acima do normal");
            necessitaExame = true;
        }
        if (respiraçao < 18){
            System.out.println("Respiracao abaixo do normal");
            necessitaExame = true;
        }
        if (batimentos > 70){
            System.out.println("Batimentos acima do normal");
            necessitaExame = true;
        }
        if (necessitaExame){
            System.out.println("Realizar exames complementares para confirmar possíveis problemas");
            System.out.println("Exame de sangue, Raio-X, Ultrassom ou Eletrocardiograma");
        } else {
            System.out.println("O animal não necessita de exames no momento");
        }
        return necessitaExame;

    }

    public boolean isNecessitaExame() {
        return necessitaExame;
    }

    public void setNecessitaExame(boolean necessitaExame) {
        this.necessitaExame = necessitaExame;
    }

    public int getBatimentos() {
        return batimentos;
    }

    public void setBatimentos(int batimentos) {
        this.batimentos = batimentos;
    }

    public int getRespiraçao() {
        return respiraçao;
    }

    public void setRespiraçao(int respiraçao) {
        this.respiraçao = respiraçao;
    }

    public double getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(double temperatura) {
        this.temperatura = temperatura;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
}
