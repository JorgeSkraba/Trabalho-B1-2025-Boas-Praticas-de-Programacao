package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

import java.util.List;
// Metodo Para Buscar Animal na lista de animais
public class BuscarAnimal {
    public boolean procurarAnimal(double cpfdono,String nomeAnimal, List<Animal> listaAnimalGeral){
        int contador = 0;
        for (int i = 0; i < listaAnimalGeral.size(); i++) {
            if (cpfdono == listaAnimalGeral.get(i).getCpfdono())
            {
                System.out.println("Nome do Animal: "+listaAnimalGeral.get(i).getNome());
                System.out.println("Idade: "+listaAnimalGeral.get(i).getIdade());
                System.out.println("Tipo: " +listaAnimalGeral.get(i).getTipo());
                System.out.println("Raça "+listaAnimalGeral.get(i).getRaca());
                System.out.println("Nome do Dono: "+ listaAnimalGeral.get(i).getNomeDono());
                System.out.println('\n');
                contador += 1;
            }
        }
        if(contador == 0){
            System.out.println("O animal não se encontra no sistema!");
            return false;
        }
        return true;
    }
}
