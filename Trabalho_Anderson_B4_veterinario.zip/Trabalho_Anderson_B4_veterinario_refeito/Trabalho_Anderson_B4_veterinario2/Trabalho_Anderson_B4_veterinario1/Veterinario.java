package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class Veterinario extends Funcionario{

    // Construtor da classe
    public Veterinario (int idade, String nome, int cpf, int salario, String funcao, int carteira){
        super(idade, nome, cpf, salario, funcao, carteira);
    }

    public void vacinar(Animal animal){
       if(animal.isVacina() == false){
           animal.setVacina(true);
           System.out.println("O animal "+animal.getNome()+" foi vacinado!");
       }else{
           System.out.println("O animal não precisa ser vacinado!");
       }
    }

    public void atender(Cliente cliente){
        System.out.println("O(a) cliente "+cliente.getNome()+" foi atendido(a)");
    }
}
