package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;


public class    Instituicao {
    // Atributos
    private int renda;
    private String nome;
    private double cnpj;
    private String endereco;

    // Construtor da classe
    public Instituicao(int renda, String nome, double cnpj, String endereco) {
        this.renda = renda;
        this.nome = nome;
        this.cnpj = cnpj;
        this.endereco = endereco;
    }

    // Getters e Setters
    public int getRenda() {
        return renda;
    }

    public void setRenda(int renda) {
        this.renda = renda;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getCnpj() {
        return cnpj;
    }

    public void setCnpj(int cnpj) {
        this.cnpj = cnpj;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    // Método para vender medicação
    public void venderMedicao(Pessoa cliente, int valorMedicacao) {
        if(cliente.getCarteira() >= valorMedicacao){
            cliente.setCarteira(cliente.getCarteira() - valorMedicacao);
            this.renda += valorMedicacao;
            System.out.println("O(a) cliente "+cliente.getNome()+" comprou "+valorMedicacao+" reais em remédios");
            return;
        }else{
            System.out.println("O cliente não possui dinheiro o suficiente!");
        }
    }

    // Método para pagar funcionário
    public void pagarFuncionario(Funcionario funcionario, int salario) {
        if(salario <= this.renda){
            funcionario.setCarteira(funcionario.getCarteira() + salario);
            this.renda -= salario;
            System.out.println("O(a) funcionário(a) "+funcionario.getNome()+" recebeu "+salario+" reais");
        }
        else{
            System.out.println("A instituicao nao possui o dinheiro suficiente!");
        }
    }

    // Método para simular a compra de itens
    public void comprarItens(int valorItens) {
        if(this.renda > valorItens){
            this.renda -= valorItens;
            System.out.println("O valor "+valorItens+" foi comprado em remédios");
            return;
        }else{
            System.out.println("A instituicao nao possui dinheiro para essa compra!");
        }
    }
}