package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class    Pessoa {
    // Atributos
    private int idade;
    private String nome;
    private int cpf;
    private int carteira;

    // Construtor da classe
 public Pessoa (int idade, String nome, int cpf, int carteira){
        this.idade = idade;
        this.nome = nome;
        this.cpf = cpf;
        this.carteira = carteira;
    }

    // Getters e Setters
    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public int getCarteira() {
        return carteira;
    }

    public void setCarteira(int carteira) {
        this.carteira = carteira;
    }
}
