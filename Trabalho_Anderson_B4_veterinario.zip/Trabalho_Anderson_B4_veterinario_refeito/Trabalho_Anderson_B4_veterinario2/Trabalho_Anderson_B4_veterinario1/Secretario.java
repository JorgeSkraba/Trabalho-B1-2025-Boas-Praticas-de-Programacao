package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class Secretario extends Funcionario{

    // Construtor da classe
    public Secretario (int idade, String nome, int cpf, int salario, String funcao, int carteira){
        super(idade, nome, cpf, salario, funcao, carteira);
    }

    public void agendar(Cliente cliente, String data){
        System.out.println("A consulta com "+cliente.getNome()+" foi agendada para "+data);
    }
}
