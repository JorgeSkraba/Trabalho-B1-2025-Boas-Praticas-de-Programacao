package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;
import java.util.List;

public class Animal {
    //atributos
    private String nome;
    private String tipo;
    private String raca;
    private int idade;
    private String nomeDono;
    private double cpfdono;
    private boolean vacina;
   //construtor
    public Animal(String nome, String tipo, String raca, int idade, String nomeDono,double cpfdono, boolean vacina){
        this.nome = nome;
        this.tipo = tipo;
        this.raca = raca;
        this.idade = idade;
        this.nomeDono = nomeDono;
        this.cpfdono = cpfdono;
        this.vacina = vacina;
    }

    // Getters e Setters

    public int getIdade() {
        return idade;
    }

    public String getRaca() {
        return raca;
    }

    public String getTipo() {
        return tipo;
    }

    public String getNome() {
        return nome;
    }

    public String getNomeDono() {
        return nomeDono;
    }

    public double getCpfdono() {
        return cpfdono;
    }

    public boolean isVacina(){ return vacina;}

    public void setVacina(boolean vacina){ this.vacina = vacina;}
}
