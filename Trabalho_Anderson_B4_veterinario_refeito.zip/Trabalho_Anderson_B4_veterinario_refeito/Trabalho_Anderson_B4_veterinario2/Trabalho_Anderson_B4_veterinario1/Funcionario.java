package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class Funcionario extends Pessoa{
    // Atributos
    private int salario;
    private String funcao;

    // Construtor da classe
    public Funcionario(int idade, String nome, int cpf, int salario, String funcao, int carteira){
        super(idade, nome, cpf, carteira);
        this.salario = salario;
        this.funcao = funcao;
    }

    // Getters e Setters
    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

}
