package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Veterinario veterinario = new Veterinario(34, "jonas", 23, 5000, "veterinario", 200);
        Secretario secretario = new Secretario(55, "Juliana", 34,3000, "secretario",300);

        // lista de animal geral utilizada para fazer o cadastro dos animais e consulta do mesmo.
        List<Animal> listaAnimalGeral = new ArrayList<>();

        // menu do sistema do veterianario
        int opcao = 0;
        do {
            System.out.println("\nOlá, escolha uma das opções abaixo: \n");
            System.out.println("1.Cadastrar Animal \n" +
                    "2.Realizar Consulta\n" +
                    "3.Agendar Consulta \n" +
                    "4.Agendar Exame \n" +
                    "5.Buscar Animal\n" +
                    "6.Sair\n");
            ;
            opcao = scanner.nextInt();
            switch (opcao){
                // caso para cadastrar um animal no sistema (adicionar à lista de animais)
                case 1:
                    System.out.println("Cadastrar Animal");

                    System.out.println("Nome do animal");
                    String nomeAnimal = scanner.next();

                    System.out.println("idade do animal");
                    int idadeAnimal = scanner.nextInt();

                    System.out.println("Tipo do animal");
                    String tipo = scanner.next();

                    System.out.println("Raça do animal");
                    String raca = scanner.next();

                    System.out.println("Digite o nome do Dono do Animal");
                    String nomeDonoAnimal = scanner.next();

                    System.out.println("CPF do Dono");
                    double cpfdono = scanner.nextDouble();

                    System.out.println("Cadastro realizado com sucesso");

                    Animal animal1 = new Animal(nomeAnimal,tipo, raca,
                            idadeAnimal,nomeDonoAnimal, cpfdono, false);

                    listaAnimalGeral.add(animal1);

                    break;

                case 2:
                    //caso para realizar a consulta, executando a busca do animal e simulando os exames
                    BuscarAnimal buscar = new BuscarAnimal();
                    boolean verificador = false;
                    for (int i = 0; i < listaAnimalGeral.size(); i++) {

                        System.out.println("Sistema de Consulta \n");
                        do {
                            System.out.print("Informe o cpf do dono do animal: ");
                            cpfdono = scanner.nextDouble();
                            System.out.println("Informe o nome do animal");
                            nomeAnimal = scanner.next();
                            verificador = buscar.procurarAnimal(cpfdono, nomeAnimal, listaAnimalGeral);
                        } while (!verificador);

                        System.out.print("Informe o peso do " + listaAnimalGeral.get(i).getNome() + ": ");
                        int peso = scanner.nextInt();

                        System.out.print("Informe a temperatura corporal do " + listaAnimalGeral.get(i).getNome() + ": ");
                        int temperatura = scanner.nextInt();

                        System.out.print("Informe a taxa de respiração do " + listaAnimalGeral.get(i).getNome() + " por minuto: ");
                        int respiracao = scanner.nextInt();

                        System.out.print("Informe a frequência cardíaca do " + listaAnimalGeral.get(i).getNome() + " animal em batimentos por minuto: ");
                        int batimentos = scanner.nextInt();

                        System.out.println("\nDiagnóstico Clínico: \n");
                        Consulta consulta = new Consulta(peso, temperatura, respiracao, batimentos);
                        Exames exames = new Exames(false, 0);
                        consulta.gerardianostico();

                        if (consulta.isNecessitaExame() == true) {
                            System.out.println("\nO Exame do " + listaAnimalGeral.get(i).getNome() + " foi positivo ou negatino (digite 1 para positivo ou 2 para negativo): ");
                            int valor = scanner.nextInt();
                            scanner.nextLine();
                            exames.setValor(valor);
                        }
                        exames.resultados();

                        if (exames.isResultado() == true) {
                            System.out.print("Descreva o resultado no Exame: ");
                            String texto = scanner.nextLine();
                            exames.setDescricao_exame(texto);
                        }

                        exames.getDescricao_exame();
                        System.out.println();

                        System.out.println("Resumo da consulta: \n");
                        System.out.println("O peso do " + listaAnimalGeral.get(i).getNome() + " é " + consulta.getPeso());
                        System.out.println("O temperatura do " + listaAnimalGeral.get(i).getNome() + " é " + consulta.getTemperatura());
                        System.out.println("A respiraçao do " + listaAnimalGeral.get(i).getNome() + " por minutos é " + consulta.getRespiraçao());
                        System.out.println("O batimentos do " + listaAnimalGeral.get(i).getNome() + " por minutos é " + consulta.getBatimentos());

                        if (exames.isResultado() == true) {
                            System.out.println("Descrição do exame: " + exames.getDescricao_exame() + "\n");
                        }
                        break;
                    }
                    break;

                case 3:
                    //simulação do agendamento
                    Cliente clienteNovo = new Cliente(18,"jose scraba", 12345678,"magrelin", 123456 );

                    System.out.println("Agendar consulta");
                    System.out.println("Informe a data da consulta: ");
                    String data = scanner.next();
                    System.out.println("Informe o convênio: ");
                    String convenio = scanner.next();
                    System.out.println("Informe a duração da consulta: ");
                    double duracao = scanner.nextInt();
                    System.out.println("Informe o valor da consulta: ");
                    double valor = 120 * (duracao /60);
                    secretario.agendar(clienteNovo,data);
                    System.out.println("valor da consulta " + valor);

                    break;
                case 4:
                    //simulação do agendamento do exame
                    System.out.println("Agendar exame");
                    System.out.println("Informe a data para realizar o exame: ");
                    String dataExame = scanner.next();
                    System.out.println("Informe o tipo de exame: ");
                    String tipoExame = scanner.next();
                    System.out.println("Informe o valor deste exame: ");
                    int valorExame = scanner.nextInt();
                    break;

                case 5:
                    //checagem se um animal está na lista de animais,e exibir seus dados
                    System.out.println("Informe o cpf do Dono: ");
                    double cpfDono= scanner.nextDouble();
                    System.out.println("Informe o nome do animal: ");
                    String nomeAnimal2 = scanner.next();
                    BuscarAnimal buscar2 = new BuscarAnimal();
                    buscar2.procurarAnimal(cpfDono, nomeAnimal2, listaAnimalGeral);
                    break;

                case 6:
                    System.out.println("Saindo do sistema");
                    break;
            }
        }while(opcao != 6);
    }
}