package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;


import java.util.ArrayList;
import java.util.List;

public class Gerente extends Funcionario {

    private List<Funcionario> ListaFuncionario = new ArrayList<>();

    // Construtor da classe
    public Gerente (int idade, String nome, int cpf, int salario, String funcao, int carteira){
        super(idade, nome, cpf, salario, funcao, carteira);
    }

    // Getters e Setters
    public List<Funcionario> getListaSecretario() {
        return ListaFuncionario;
    }

    public void setListaFuncionario(List<Funcionario> listaFuncionario) {
        this.ListaFuncionario = listaFuncionario;
    }

    //contrata um funcionario novo (adiciona na lista de funcionarios)
    public void contratar (Funcionario funcionarioNovo){
      this.ListaFuncionario.add(funcionarioNovo);
    }

    //demiti um funcionario (retira-o da lista de funcionarios)
    public void demitir(Funcionario funcionario){
       this.ListaFuncionario.remove(funcionario);
    }
}
