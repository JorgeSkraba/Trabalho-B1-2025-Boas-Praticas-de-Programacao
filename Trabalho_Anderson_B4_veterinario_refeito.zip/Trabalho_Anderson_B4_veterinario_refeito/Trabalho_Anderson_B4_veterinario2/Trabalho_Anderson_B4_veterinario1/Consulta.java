package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class    Consulta {
    // Atributos
    private double peso;
    private double temperatura;
    private int respiracao;
    private int batimentos;
    private boolean necessitaExame = false;

    // Construtor da classe
    public Consulta(double peso, double temperatura, int respiracao, int batimentos){
        this.peso = peso;
        this.temperatura = temperatura;
        this.respiracao = respiracao;
        this.batimentos = batimentos;
    }
    //metodo para o dianostico do animal
    public boolean gerardianostico(){

        if(peso < 30.0){
            System.out.println("Peso abaixo do ideal");
            necessitaExame = true;
        }
        if (temperatura > 37){
            System.out.println("Temperatura acima do normal");
            necessitaExame = true;
        }
        if (respiracao < 18){
            System.out.println("Respiracao abaixo do normal");
            necessitaExame = true;
        }
        if (batimentos > 70){
            System.out.println("Batimentos acima do normal");
            necessitaExame = true;
        }
        if (necessitaExame){
            System.out.println("Realizar exames complementares para confirmar possíveis problemas");
            System.out.println("Exame de sangue, Raio-X, Ultrassom ou Eletrocardiograma");
        } else {
            System.out.println("O animal não necessita de exames no momento");
        }
        return necessitaExame;
    }

    // Getters e Setters
    public boolean isNecessitaExame() {
        return necessitaExame;
    }

    public int getBatimentos() {
        return batimentos;
    }

    public int getRespiraçao() {
        return respiracao;
    }

    public double getTemperatura() {
        return temperatura;
    }

    public double getPeso() {
        return peso;
    }
}