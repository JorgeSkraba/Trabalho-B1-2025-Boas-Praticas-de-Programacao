package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

import java.util.Scanner;

public class Exames {
    // Atributos
    private int valor;
    private boolean resultado;
    private String descricao_exame;

    // Construtor da classe
    public Exames(boolean resultado, int valor) {
        this.resultado = resultado;
        this.valor = valor;
    }
    //Metodo para validar se exame foi positivo
    public void resultados() {
        if (valor == 1) {
            resultado = true;
        }

        if (valor == 2) {
            System.out.println("O exame do animal foi negativo");
        }
    }

    // Getters e Setters
    public boolean isResultado() {
        return resultado;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public String getDescricao_exame() {
        return descricao_exame;
    }

    public void setDescricao_exame(String descricao_exame) {
        this.descricao_exame = descricao_exame;
    }
}


