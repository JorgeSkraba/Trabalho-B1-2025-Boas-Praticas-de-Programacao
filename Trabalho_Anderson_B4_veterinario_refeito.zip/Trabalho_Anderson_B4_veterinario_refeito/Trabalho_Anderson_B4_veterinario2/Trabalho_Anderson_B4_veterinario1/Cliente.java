package POO_B4_Anderson.Trabalho_Anderson_B4_veterinario;

public class Cliente extends Pessoa{
    private String pet;

    public Cliente(int idade, String nome, int cpf, String pet, int carteira){
        super(idade, nome, cpf, carteira);
        this.pet = pet;
    }
}
